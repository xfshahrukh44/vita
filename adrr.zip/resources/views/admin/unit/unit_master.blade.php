@csrf
<div class="modal-body">
    <!-- name -->
    <div class="form-group">
        <label for="">Name</label>
        <input id="name" type="text" name="name" placeholder="Enter brand name"
        class="form-control" required max="50">
    </div>
</div>