@csrf
<div class="modal-body">
    <!-- name -->
    <div class="form-group">
        <label for="">Name</label>
        <input id="name" type="text" name="name" placeholder="Enter hub name"
        class="form-control" required max="50">
    </div>
</div>