<?php

namespace App\Services;

use App\Repositories\InvoiceRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Invoice;


class InvoiceService extends InvoiceRepository
{
    
}