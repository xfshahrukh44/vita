<?php

namespace App\Services;

use App\Repositories\AreaRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Area;


class AreaService extends AreaRepository
{
    
}