<?php

namespace App\Services;

use App\Repositories\UnitRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Unit;


class UnitService extends UnitRepository
{
    
}