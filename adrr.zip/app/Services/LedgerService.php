<?php

namespace App\Services;

use App\Repositories\LedgerRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Ledger;


class LedgerService extends LedgerRepository
{
    
}