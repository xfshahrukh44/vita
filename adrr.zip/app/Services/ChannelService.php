<?php

namespace App\Services;

use App\Repositories\ChannelRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Channel;


class ChannelService extends ChannelRepository
{
    
}