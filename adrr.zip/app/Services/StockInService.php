<?php

namespace App\Services;

use App\Repositories\StockInRepository;
use Illuminate\Support\Facades\DB;
use App\Models\StockIn;


class StockInService extends StockInRepository
{
    
}