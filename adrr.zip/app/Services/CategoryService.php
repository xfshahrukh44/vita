<?php

namespace App\Services;

use App\Repositories\CategoryRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Category;


class CategoryService extends CategoryRepository
{
    
}