<?php

namespace App\Services;

use App\Repositories\HubRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Hub;


class HubService extends HubRepository
{
    
}