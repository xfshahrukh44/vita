<?php

namespace App\Services;

use App\Repositories\BrandRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Brand;


class BrandService extends BrandRepository
{
    
}