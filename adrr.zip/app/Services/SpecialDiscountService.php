<?php

namespace App\Services;

use App\Repositories\SpecialDiscountRepository;
use Illuminate\Support\Facades\DB;
use App\Models\SpecialDiscount;


class SpecialDiscountService extends SpecialDiscountRepository
{
    
}