<?php

namespace App\Services;

use App\Repositories\InvoiceProductRepository;
use Illuminate\Support\Facades\DB;
use App\Models\InvoiceProduct;


class InvoiceProductService extends InvoiceProductRepository
{
    
}