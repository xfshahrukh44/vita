<?php

namespace App\Services;

use App\Repositories\VendorRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Basket;


class VendorService extends VendorRepository
{
    
}