<?php

namespace App\Services;

use App\Repositories\PaymentRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Payment;


class PaymentService extends PaymentRepository
{
    
}