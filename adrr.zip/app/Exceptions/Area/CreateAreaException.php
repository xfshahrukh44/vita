<?php

namespace App\Exceptions\Area;

use Exception;

class CreateAreaException extends Exception
{
    //
}
