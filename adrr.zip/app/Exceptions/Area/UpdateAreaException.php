<?php

namespace App\Exceptions\Area;

use Exception;

class UpdateAreaException extends Exception
{
    //
}
