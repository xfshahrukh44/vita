<?php

namespace App\Exceptions\Area;

use Exception;

class DeleteAreaException extends Exception
{
    //
}
