<?php

namespace App\Exceptions\Brand;

use Exception;

class DeleteBrandException extends Exception
{
    //
}
