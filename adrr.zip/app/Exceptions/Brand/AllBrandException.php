<?php

namespace App\Exceptions\Brand;

use Exception;

class AllBrandException extends Exception
{
    //
}
