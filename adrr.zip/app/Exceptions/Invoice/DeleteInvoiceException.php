<?php

namespace App\Exceptions\Invoice;

use Exception;

class DeleteInvoiceException extends Exception
{
    //
}
