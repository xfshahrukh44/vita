<?php

namespace App\Exceptions\Invoice;

use Exception;

class UpdateInvoiceException extends Exception
{
    //
}
