<?php

namespace App\Exceptions\Order;

use Exception;

class UpdateOrderException extends Exception
{
    //
}
