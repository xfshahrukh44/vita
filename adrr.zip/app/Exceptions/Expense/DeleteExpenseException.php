<?php

namespace App\Exceptions\Expense;

use Exception;

class DeleteExpenseException extends Exception
{
    //
}
