<?php

namespace App\Exceptions\Expense;

use Exception;

class AllExpenseException extends Exception
{
    //
}
