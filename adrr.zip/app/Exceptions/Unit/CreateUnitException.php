<?php

namespace App\Exceptions\Unit;

use Exception;

class CreateUnitException extends Exception
{
    //
}
