<?php

namespace App\Exceptions\Channel;

use Exception;

class UpdateChannelException extends Exception
{
    //
}
