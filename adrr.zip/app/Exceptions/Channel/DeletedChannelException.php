<?php

namespace App\Exceptions\Channel;

use Exception;

class DeletedChannelException extends Exception
{
    //
}
