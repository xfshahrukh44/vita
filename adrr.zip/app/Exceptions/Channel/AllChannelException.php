<?php

namespace App\Exceptions\Channel;

use Exception;

class AllChannelException extends Exception
{
    //
}
