<?php

namespace App\Exceptions\Ledger;

use Exception;

class DeleteLedgerException extends Exception
{
    //
}
