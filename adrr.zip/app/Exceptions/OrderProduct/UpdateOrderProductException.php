<?php

namespace App\Exceptions\OrderProduct;

use Exception;

class UpdateOrderProductException extends Exception
{
    //
}
