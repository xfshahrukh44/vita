<?php

namespace App\Exceptions\StockIn;

use Exception;

class AllStockInException extends Exception
{
    //
}
