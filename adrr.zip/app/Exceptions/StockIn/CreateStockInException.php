<?php

namespace App\Exceptions\StockIn;

use Exception;

class CreateStockInException extends Exception
{
    //
}
