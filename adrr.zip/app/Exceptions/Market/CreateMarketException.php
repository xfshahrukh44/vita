<?php

namespace App\Exceptions\Market;

use Exception;

class CreateMarketException extends Exception
{
    //
}
