<?php

namespace App\Exceptions\Market;

use Exception;

class UpdateMarketException extends Exception
{
    //
}
