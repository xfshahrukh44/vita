<?php

namespace App\Exceptions\StockOut;

use Exception;

class AllStockOutException extends Exception
{
    //
}
