<?php

namespace App\Exceptions\StockOut;

use Exception;

class CreateStockOutException extends Exception
{
    //
}
