<?php

namespace App\Exceptions\User;

use Exception;

class AllUserException extends Exception
{
    //
}
