<?php

namespace App\Exceptions\SpecialDiscount;

use Exception;

class UpdateSpecialDiscountException extends Exception
{
    //
}
