<?php

namespace App\Exceptions\InvoiceProduct;

use Exception;

class AllInvoiceProductException extends Exception
{
    //
}
