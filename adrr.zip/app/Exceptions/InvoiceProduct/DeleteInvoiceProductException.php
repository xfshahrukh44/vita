<?php

namespace App\Exceptions\InvoiceProduct;

use Exception;

class DeleteInvoiceProductException extends Exception
{
    //
}
