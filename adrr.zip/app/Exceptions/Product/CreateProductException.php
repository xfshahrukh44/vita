<?php

namespace App\Exceptions\Product;

use Exception;

class CreateProductException extends Exception
{
    //
}
