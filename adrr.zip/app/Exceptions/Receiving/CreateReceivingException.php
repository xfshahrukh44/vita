<?php

namespace App\Exceptions\Receiving;

use Exception;

class CreateReceivingException extends Exception
{
    //
}
