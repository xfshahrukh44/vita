<?php

namespace App\Exceptions\Receiving;

use Exception;

class DeleteReceivingException extends Exception
{
    //
}
