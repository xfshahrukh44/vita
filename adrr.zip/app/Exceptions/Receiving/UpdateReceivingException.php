<?php

namespace App\Exceptions\Receiving;

use Exception;

class UpdateReceivingException extends Exception
{
    //
}
