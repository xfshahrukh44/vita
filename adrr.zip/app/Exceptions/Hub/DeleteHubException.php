<?php

namespace App\Exceptions\Hub;

use Exception;

class DeleteHubException extends Exception
{
    //
}
