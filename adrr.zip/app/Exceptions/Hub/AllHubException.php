<?php

namespace App\Exceptions\Hub;

use Exception;

class AllHubException extends Exception
{
    //
}
