<?php

namespace App\Exceptions\Hub;

use Exception;

class UpdateHubException extends Exception
{
    //
}
