<?php

namespace App\Exceptions\Hub;

use Exception;

class CreateHubException extends Exception
{
    //
}
