<?php

namespace App\Exceptions\Category;

use Exception;

class AllCategoryException extends Exception
{
    //
}
