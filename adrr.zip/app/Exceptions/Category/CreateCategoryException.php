<?php

namespace App\Exceptions\Category;

use Exception;

class CreateCategoryException extends Exception
{
    //
}
